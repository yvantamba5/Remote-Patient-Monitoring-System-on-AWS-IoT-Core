/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n\
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n\
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n\
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n\
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n\
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n\
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n\
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n\
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n\
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n\
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n\
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n\
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n\
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n\
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n\
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n\
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n\
rqXRfboQnoZsG4q5WTP468SQvvG5\n\
-----END CERTIFICATE-----\n"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDWTCCAkGgAwIBAgIUSVm6BGjeFKokuZj3InrdFuZvGtkwDQYJKoZIhvcNAQEL\n\
BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n\
SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTIyMDExMTAxNTEw\n\
NVoXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\n\
ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALRd5hV7MobWmRTD+YdM\n\
QSf9olDmUTOmd55GW4PL9+pndu3f7kgkscOYyY54bPnAo5+kO6mlW/z2WBthWcgU\n\
+Sb49Bbnl6v4+uu9QPCvF/wsVYcxwyzmaHYxe+w+F7YG8jwzY+YEjvWYbC/Audlp\n\
GoKRNVuZHlTZiFlQHHZ7WybFR2xc1UZiHhLcoLUSPsTDMbW2/Y0iLpLJk7VGUS3n\n\
CI+AlZXeRPclgh+GkPlPtJhqP+bpcJqsPWhsQXtafRuiruz54Wttvr5aQVvfNjHS\n\
P/p2XxX7vvfaoGZSOa3TITQzklpYBAC+k1RJZWuj0nnIpgApJcef9TxrHqEupH4B\n\
NtUCAwEAAaNgMF4wHwYDVR0jBBgwFoAU1SAQ6vmc0pl2zH4QsZ4HfPemK1gwHQYD\n\
VR0OBBYEFBSZC9CrMKJgR/p2tkVXq2aetL+WMAwGA1UdEwEB/wQCMAAwDgYDVR0P\n\
AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQA85T/63KEJ/wMLstlpWrKyGhGG\n\
zBHigrpoZJSWKM8u6byJN+OZZnzPiYKZYLE6WSovY98jqz3Z+QR9s12KHdWLUoFV\n\
JRvIZOWXo5z7xRFk+nufFeMVpX5aMiPPkzXZCUBCUaNsM9XcA+8CFthxu7WEu53c\n\
rUSQeffr1a2BmPG1cEHpnT4DCwriBXEBhE5HxAel9TF2zDxCvmwPzdlgr95wzRuo\n\
hgH81aAM8CxaX6V4eitnzm1WsfHNsqS05a8HXoKG57bbeE/w6Xwxou0NDILoB2qc\n\
53xi0/Qzxo8LgTHOEBlYBLTwAGAaDsOqOl8Xp0ZWxJ/CpKv7BWrsAvRDD+eI\n\
-----END CERTIFICATE-----\n"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n\
MIIEogIBAAKCAQEAtF3mFXsyhtaZFMP5h0xBJ/2iUOZRM6Z3nkZbg8v36md27d/u\n\
SCSxw5jJjnhs+cCjn6Q7qaVb/PZYG2FZyBT5Jvj0FueXq/j6671A8K8X/CxVhzHD\n\
LOZodjF77D4XtgbyPDNj5gSO9ZhsL8C52WkagpE1W5keVNmIWVAcdntbJsVHbFzV\n\
RmIeEtygtRI+xMMxtbb9jSIuksmTtUZRLecIj4CVld5E9yWCH4aQ+U+0mGo/5ulw\n\
mqw9aGxBe1p9G6Ku7Pnha22+vlpBW982MdI/+nZfFfu+99qgZlI5rdMhNDOSWlgE\n\
AL6TVElla6PSecimACklx5/1PGseoS6kfgE21QIDAQABAoIBAB3Im6PUciV97k1V\n\
hzDmUKQP5+u//Iyw4nPKXnZHCis05pilL63OEWShKDdUf3pGaz6DWi7LVYNSEn6C\n\
9tZpUDM1TOkzWQJW3OhsmfqkjytfDsiCWR5i9cD+rt316uhuATYbrlVfT1QS1VqV\n\
UpsqFeyVmeAEStPsD+3forOV7xlZlzFeRgTv0/0JafLixESB7//tsgOguRpQQbj0\n\
c6mRYfoznnqYHPlcSUVXWMoSXLBT4ilk3Zu++ZI0+/4E8ku3c6tBlpW35morapnC\n\
FEBdjxZ0QWx9jr/x50oWPJlWeWXCfCZeoehJo8L7gmi3zimG/aRn0wZwIfQavuyu\n\
JegNVcECgYEA5WU2gV4HcenjuaiBOOV/ZIipEuCa59PRvSlm575eZcWCyaXBbOSg\n\
OJl0Hl3j9dh9EJ42zIHf8FlgnTybznQtMtpC/TrVrpiYvneZVFGqm9DPchNwlhMI\n\
/XRjrbQ9equeqNsaopxvCVsd4U/saet2M5Swz2u7g7ylYqcZESYIU90CgYEAyUkE\n\
8M9Ib5TbBqVRIDG5Hu7AwPYsnHL0VhF5lXtWNo0clHv/VQiCGji0M3XsXaayOTyD\n\
u2gf9ovWvj4Pb0n6cXVsPQJP9TnR3Nl4UM840/5s4Mk6Cg8NXHOrfaZWzdfs0XFb\n\
79LXCV4BzVciT38z2zpfs6ZtWitOP+TE2Vv221kCgYBiHYNNm+k1SOO1IiR7MHXn\n\
iyg9wcGfzJKWBOJV1q/Lecox82qi57q72q622lPJcFo1xGYN3LLqu1++gRDnIfu/\n\
F2m1o/eHYQ9b0A3N6cw+Lva7hSMPnX6n4aNMxZ3SHRuUf3qJ+LzpVIaYOzYUK7j3\n\
4O4rGZovg319j5kCI7FGJQKBgDCc5giSx1fLh6pvOsyftan2167CxbtzN/eheM/V\n\
XdkG86QY3m3XBDT5BOx4yoFDxT91kgss9qtA0rhXnLqwD0Bfr6h8ans7X6gLDbfW\n\
lE7+36TadJ4BTKTLett51PUZ9SQQULf3H+AvSBgjtzGj8w47ZumohDiGxPtBcRld\n\
0JzhAoGAOt9pV7vjajEVS/bflgcojPUgfUDptT8oKA5IAVawCFonlrSl9zo+6YkE\n\
GRbL2qzIR5VLP9+GAOIQsyNqsfY0pkJsMp41tCk4nfCpoVIoOXp53S08HrzQngth\n\
mGROCEmTgQE+VQFl4J3qYl8SxmqtD8K37y/PncAiKO4/TDkUw6s=\n\

-----END RSA PRIVATE KEY-----\n"};


#ifdef __cplusplus
}
#endif
